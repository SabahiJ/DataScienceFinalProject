Financial Sentiment Trend Prediction Tool

Overview
This project investigates the use of Natural Language Processing (NLP) and financial news sentiment analysis to predict short-term stock market trends for Nvidia Corporation (NVDA)... [trimmed for brevity]
